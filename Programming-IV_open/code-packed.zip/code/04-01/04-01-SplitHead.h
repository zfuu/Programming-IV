// Keisanki Joron 2 (Introduction to Computing II)
// Dept. of Engineering Systems, University of Tsukuba
// [UTF-8 / Unix]
// 計算機序論２・実習 (筑波大学工学システム学類)

// 2011/11/25a kameda[at]iit.tsukuba.ac.jp
// 04.1. C言語プログラムのソースファイル分割
// ヘッダ使用しての分割後 (04-1-SplitHead.h) 

float operation_add(float v1, float v2) ;
// Function prototype宣言では関数の引数名に意味はないので、
// float operation_add(float, float) ;
// でも可。
