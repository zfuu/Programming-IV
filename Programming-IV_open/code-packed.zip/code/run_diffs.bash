
# ic2 for 2012
# kameda[at]iit.tsukuba.ac.jp
# 2012/11/05, xx:xx at Casper34J
# cd $HOME/ic2-2012-T/code; bash run_diffs.bash

runcmd=~/scripts/diff2html_utf.pl
EWS=~/workspace-ic2/

function gogoc {
$runcmd ../${OWD}/${OWD}-${FF}.c ${TWD}-${FF}.c > ${OWD}_${TWD}-${FF}.html
echo '<li><a href="code/'$TWD'/'$TWD'-'$FF'.c">'${TWD}'-'${FF}'.c</a> (<a href="code/'$TWD'/'$OWD'_'$TWD'-'$FF'.html">'$OWD'からの差分</a>)'
}

function gogoh {
FF="ic2-CommonHeaders.h"
$runcmd ../${OWD}/${FF} ${FF} > ${OWD}_${TWD}-headers.html
echo '<li><a href="code/'$TWD'/'$FF'">'${FF}'</a> (<a href="code/'$TWD'/'$OWD'_'$TWD'-headers.html">'$OWD'からの差分</a>)'
}

TWD="11-03"
mkdir -p $TWD ; cd $TWD ; cp -p $EWS/$TWD/*.[cht] .
OWD="07-05"; FF="MainFunction"; gogoc
cd ..

exit 0

TWD="11-02"
mkdir -p $TWD ; cd $TWD ; cp -p $EWS/$TWD/*.[cht] .
OWD="11-01"; gogoh
OWD="10-02"; FF="ReadModel"; gogoc
cd ..

TWD="11-01"
mkdir -p $TWD ; cd $TWD ; cp -p $EWS/$TWD/*.[cht] .
cd ..

TWD="10-02"
mkdir -p $TWD ; cd $TWD ; cp -p $EWS/$TWD/*.[cht] .
OWD="10-01"; FF="MainFunction" ; gogoc
OWD="10-01"; FF="ReadModel" ; gogoc
cd ..

TWD="10-01"
mkdir -p $TWD ; cd $TWD ; cp -p $EWS/$TWD/*.[cht] .
cd ..

TWD="09-03"
mkdir -p $TWD ; cd $TWD ; cp -p $EWS/$TWD/*.[ch] .
OWD="09-02"; FF="Rendering" ; gogoc
OWD="07-05"; FF="Callback"  ; gogoc
cd ..

TWD="09-02"
mkdir -p $TWD ; cd $TWD ; cp -p $EWS/$TWD/*.[ch] .
OWD="09-01"; FF="Projection"; gogoc
OWD="09-01"; FF="Rendering" ; gogoc
cd ..

TWD="09-01"
mkdir -p $TWD ; cd $TWD ; cp -p $EWS/$TWD/*.[ch] .
OWD="08-01"; gogoh
OWD="07-03"; FF="Projection"; gogoc
OWD="08-04"; FF="Rendering" ; gogoc
cd ..

cd 08-04; cp -p $EWS/08-04/*.[ch] .
$runcmd ../08-03/08-03-Rendering.c        08-04-Rendering.c      > 08-03_08-04-Rendering.html
cd ..

cd 08-03; cp -p $EWS/08-03/*.[ch] .
$runcmd ../08-02/08-02-Rendering.c        08-03-Rendering.c      > 08-02_08-03-Rendering.html
cd ..

cd 08-02; cp -p $EWS/08-02/*.[ch] .
$runcmd ../08-01/08-01-Rendering.c        08-02-Rendering.c      > 08-01_08-02-Rendering.html
cd ..

cd 08-01; cp -p $EWS/08-01/*.[ch] .
$runcmd ../07-05/ic2-CommonHeaders.h      ic2-CommonHeaders.h    > 07-05_08-01-headers.html  
$runcmd ../07-05/07-05-Rendering.c        08-01-Rendering.c      > 07-05_08-01-Rendering.html
cd ..

cd 01-2; $runcmd ../01-1/01-1-HelloESYS-NotSoGood.c 01-2-HelloESYS-Better.c > 01-1_01-2.html ; cd ..;
cd 01-3; $runcmd ../01-2/01-2-HelloESYS-Better.c    01-3-HelloESYS-Full.c   > 01-2_01-3.html ; cd ..;

cd 02-2; $runcmd ../02-1/02-1-OpenFile-NotSoGood.c  02-2-OpenFile-Full.c    > 02-1_02-2.html ; cd ..;

cd 03-3; $runcmd ../03-2/03-2-fgets.c               03-3-sscanf.c           > 03-2_03-3.html ; cd ..;
cd 03-4; $runcmd ../03-3/03-3-sscanf.c              03-4-SimpleCalculator.c > 03-3_03-4.html ; cd ..;

cd 06-02; $runcmd ../06-01/06-01-Preparation.c      06-02-SwapBuffers.c      > 06-01_06-02.html ; cd ..;
cd 06-03; $runcmd ../06-02/06-02-SwapBuffers.c      06-03-SwapBuffersCheck.c > 06-02_06-03.html ; cd ..;
cd 06-04; $runcmd ../06-03/06-03-SwapBuffersCheck.c 06-04-SwapByTimer.c      > 06-03_06-04.html ; cd ..;
cd 06-05; $runcmd ../06-04/06-04-SwapByTimer.c      06-05-OrthogonalCamera.c > 06-04_06-05.html ; cd ..;
cd 06-06; $runcmd ../06-05/06-05-OrthogonalCamera.c 06-06-LogoOpenGL.c       > 06-05_06-06.html ; cd ..;
cd 06-07; $runcmd ../06-06/06-06-LogoOpenGL.c       06-07-Periodic.c         > 06-06_06-07.html ; cd ..;
#
cd 06-09; $runcmd ../06-06/06-06-LogoOpenGL.c       06-09-LogoOpenGL.c       > 06-06_06-09.html ; cd ..;

cd 07-01; $runcmd ../06-09/06-09-LogoOpenGL.c       07-01-Planning.c         > 06-09_07-01.html ; cd ..;

cd 07-02; $runcmd ../07-01/07-01-Planning.c         07-02-CommonHeaders.h    > 07-01_07-02-CommonHeaders.html  ; cd .. ;
cd 07-02; $runcmd ../07-01/07-01-Planning.c         07-02-Callback.c         > 07-01_07-02-Callback.html       ; cd .. ;
cd 07-02; $runcmd ../07-01/07-01-Planning.c         07-02-EmbededObjects.c   > 07-01_07-02-EmbededObjects.html ; cd .. ;
cd 07-02; $runcmd ../07-01/07-01-Planning.c         07-02-Initialization.c   > 07-01_07-02-Initialization.html ; cd .. ;
cd 07-02; $runcmd ../07-01/07-01-Planning.c         07-02-MainFunction.c     > 07-01_07-02-MainFunction.html   ; cd .. ;
cd 07-02; $runcmd ../07-01/07-01-Planning.c         07-02-Projection.c       > 07-01_07-02-Projection.html     ; cd .. ;
cd 07-02; $runcmd ../07-01/07-01-Planning.c         07-02-Rendering.c        > 07-01_07-02-Rendering.html      ; cd .. ;

cd 07-03; $runcmd ../07-02/07-02-CommonHeaders.h    ic2-CommonHeaders.h      > 07-02_ic2-CommonHeaders.html    ; cd .. ;
cd 07-03; $runcmd ../07-02/07-02-Callback.c         07-03-Callback.c         > 07-02_07-03-Callback.html       ; cd .. ;
cd 07-03; $runcmd ../07-02/07-02-EmbededObjects.c   07-03-EmbededObjects.c   > 07-02_07-03-EmbededObjects.html ; cd .. ;
cd 07-03; $runcmd ../07-02/07-02-Initialization.c   07-03-Initialization.c   > 07-02_07-03-Initialization.html ; cd .. ;
cd 07-03; $runcmd ../07-02/07-02-MainFunction.c     07-03-MainFunction.c     > 07-02_07-03-MainFunction.html   ; cd .. ;
cd 07-03; $runcmd ../07-02/07-02-Projection.c       07-03-Projection.c       > 07-02_07-03-Projection.html     ; cd .. ;
cd 07-03; $runcmd ../07-02/07-02-Rendering.c        07-03-Rendering.c        > 07-02_07-03-Rendering.html      ; cd .. ;

cd 07-04; $runcmd ../07-03/ic2-CommonHeaders.h      ic2-CommonHeaders.h      > 07-03_07-04-headers.html        ; cd .. ;
cd 07-04; $runcmd ../07-03/07-03-Callback.c         07-04-Callback.c         > 07-03_07-04-Callback.html       ; cd .. ;
cd 07-04; $runcmd ../07-03/07-03-Initialization.c   07-04-Initialization.c   > 07-03_07-04-Initialization.html ; cd .. ;

cd 07-05; $runcmd ../07-04/ic2-CommonHeaders.h      ic2-CommonHeaders.h      > 07-04_07-05-headers.html        ; cd .. ;
cd 07-05; $runcmd ../07-04/07-04-Callback.c         07-05-Callback.c         > 07-04_07-05-Callback.html       ; cd .. ;
cd 07-05; $runcmd ../07-03/07-03-Rendering.c        07-05-Rendering.c        > 07-03_07-05-Rendering.html      ; cd .. ;
cd 07-05; $runcmd ../07-03/07-03-MainFunction.c     07-05-MainFunction.c     > 07-03_07-05-MainFunction.html   ; cd .. ;

exit 0

pushd 106-6; $runcmd ../106-5/106-5-MoveTheWorld.c 106-6-ShowXYZ.c > 106-5_106-6.html ; popd
pushd 107-6; $runcmd ../106-6/106-6-ShowXYZ.c 107-6-MoveObjectOnly.c > 106-6_107-6.html ; popd
pushd 107-7; $runcmd ../107-6/106-6-ShowXYZ.c 107-7-MoveLightOnly.c > 106-6_107-7.html ; popd

pushd 108-1; $runcmd ../106-6/106-6-ShowXYZ.c 108-1-Ortho.c > 106-6_108-1.html ; popd
pushd 108-2; $runcmd ../108-1/108-1-Ortho.c 108-2-Viewpoint.c > 108-1_108-2.html ; popd
pushd 108-3; $runcmd ../108-2/108-2-Viewpoint.c 108-3-ViewpointCentering.c > 108-2_108-3.html ; popd
pushd 109-2; $runcmd ../102-2/102-2-ReadFile-Full.c 109-2-OpenFile.c > 102-2_109-2.html ; popd
pushd 109-3; $runcmd ../109-2/109-2-OpenFile.c 109-3-ReadLine.c > 109-2_109-3.html ; popd
pushd 109-4; $runcmd ../109-3/109-3-ReadLine.c 109-4-ReadModel.c > 109-3_109-4.html ; popd
pushd 110-1; $runcmd ../109-4/109-4-ReadModel.c 110-1-MergedSource.c > 109-4_110-1.html ; popd
pushd 110-2; $runcmd ../110-1/110-1-MergedSource.c 110-2-TogglePredefined.c > 110-1_110-2.html ; popd
pushd 110-3; $runcmd ../110-2/110-2-TogglePredefined.c 110-3-ModelShow.c > 110-2_110-3.html ; popd

pushd 110-4; $runcmd ../110-3/110-3-ModelShow.c 110-4-NormalVector.c > 110-3_110-4.html ; popd
pushd 110-5; $runcmd ../110-4/110-4-NormalVector.c 110-5-ShowNormal.c > 110-4_110-5.html ; popd
pushd 110-6; $runcmd ../110-5/110-5-ShowNormal.c 110-6-MoveLight.c > 110-5_110-6.html ; popd

pushd 111-1; $runcmd ../110-6/110-6-MoveLight.c 111-1-Perspective.c > 110-6_111-1.html ; popd

pushd 112-1; $runcmd ../111-1/111-1-Perspective.c 112-0-Structures.c    > 111-1_112-0.html ; popd

pushd 112-1; $runcmd          112-0-Structures.c  112-1-Memory.c        > 112-0_112-1.html ; popd
pushd 112-2; $runcmd ../112-1/112-1-Memory.c      112-2-Replay.c        > 112-1_112-2.html ; popd
pushd 112-3; $runcmd ../112-2/112-2-Replay.c      112-3-AnimationFile.c > 112-2_112-3.html ; popd
