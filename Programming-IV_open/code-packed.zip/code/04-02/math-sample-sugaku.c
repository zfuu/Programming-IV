#include <stdio.h>
#include "sugaku.h"
int main(int argc, char *argv[]){
  printf("sin(90[degree]) is %f\n", sin(1.57078));
  return 0;
}
