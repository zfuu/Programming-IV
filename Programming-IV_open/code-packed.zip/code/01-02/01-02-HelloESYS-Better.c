// Keisanki Joron 2 (Introduction to Computing II)
// Dept. of Engineering Systems, University of Tsukuba
// [UTF-8 / Unix]
// 計算機序論２・実習 (筑波大学工学システム学類)

// 2011/11/22a kameda[at]iit.tsukuba.ac.jp
// 01.2 上品なHello ESYS

#include <stdio.h>

int main(int argc, char *argv[]){
  printf("Hello, ESYS folks.\n");
  return 0;
}

